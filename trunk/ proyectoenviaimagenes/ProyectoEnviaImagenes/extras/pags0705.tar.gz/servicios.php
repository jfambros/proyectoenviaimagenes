<?php

   function obtieneListaContacto($correoUsuario){
      $link = mysql_connect("localhost", "root","root"); 
      mysql_select_db("turismo", $link); 
      $result = mysql_query("select * from contacto where correoUsuario = '".$correoUsuario."'", $link); 
    
	  $cont = 0;
	  while ($row = mysql_fetch_row($result)){ 
         $contacto[$cont] = array("idNuevoContacto" =>$row[0],"nombreContacto" => utf8_encode($row[1]),"emailContacto" => $row[2],
         "telefonoContacto" => $row[3], "correoUsuario" => $row[4]);
		   $cont++;
      }
	  $listaContactos = array("contactos"=>$contacto);
     return $listaContactos;   	
   }

   function obtieneImagenes($opciones){
   	$link = mysql_connect("localhost", "root","root"); 
      mysql_select_db("turismo", $link); 
      $result = mysql_query($opciones, $link);
      
      $cont = 0;
	  while ($row = mysql_fetch_row($result)){ 
         $cat[$cont] = array("nombreImagen" =>utf8_encode($row[0]),"latitud" => $row[1], "longitud" => $row[2], "idCategoria" => $row[4], "comentario" => utf8_encode($row[3]), "nombreCategoria"=> utf8_encode($row[6]), "calificacion"=>$row[5]);
		   $cont++;
      }
	 $listaImagenes = array("imagenes"=>$cat);
     return $listaImagenes;   	
     
   }
   
   function nuevoUsuario($correoUsuario, $nombreUsuario, $contraUsuario){
 			$link = mysql_connect("localhost", "root","root"); 
      	mysql_select_db("turismo", $link); 
      	mysql_query("SET NAMES 'utf8'");
      	$result = mysql_query("insert into usuario values('".$correoUsuario."','".$nombreUsuario."','".
      	$contraUsuario."');", $link);
      	 
   		return "Usuario insertado";  	
   }
   
      function nuevoContacto($nombreContacto, $emailContacto, $telefonoContacto, $correoUsuario){
 			$link = mysql_connect("localhost", "root","root"); 
      	mysql_select_db("turismo", $link); 
      	mysql_query("SET NAMES 'utf8'");
 			$idContacto =  mysql_insert_id();
      	$result = mysql_query("insert into contacto values(".$idContacto.",'".$nombreContacto."','".
      	$emailContacto."','".$telefonoContacto."','".$correoUsuario."');", $link);
      	 
   		return "Contacto insertado";  	
   }
   
  function validaUsuario($correoElectronico, $contrasenia){
 	$link = mysql_connect("localhost", "root","root"); 
	mysql_select_db("turismo", $link); 
	$result = mysql_query("select count(correoElectronico), correoElectronico, nombre from usuario where contrasenia = '".$contrasenia."' and correoElectronico = '".$correoElectronico."'", $link);
		  
		  while ($row = mysql_fetch_row($result)){ 
			   $total = $row[0];
			   $correo = $row[1];
			   $nombre = $row[2];
			 }
			 
		if ($total != 0){
			return array("nombreUsuario"=>$nombre, "correoUsuario"=>$correo);
		}else {
			return array("nombreUsuario"=>"null", "correoUsuario"=>"null");
		}
		  
		   
  }   
   
	function recibeImaArreglo($nombreImagen, $contenido, $latitud, $longitud, $comentario, $categoria, $width, $heigth){
		
	   $cant = count($contenido);
		header('Content-Type: image/jpeg');
		
      $cadena = "";
		for ($i=0; $i<$cant; $i++){
		   $cadena .= $contenido[$i];
		}
		
		$data = base64_decode($cadena);
	   $file = $nombreImagen.".jpg";
	   $success = file_put_contents($file, $data);	   		
	   
	   return "cantidad ".$cant;
/*		
		// binary, utf-8 bytes
   	$binary=base64_decode($cadena);
   	

//activar la biblioteca de funciones gd

		$img = imagecreatefromstring($binary);
		
		if($img != false)
		{
   		imagejpeg($img,$nombreImagen."jpg");
   		return "recibido";
		}
		else {
		   return "error";	
		}					
	
		
		 imagedestroy($img);
*/	
		/*
		$data = base64_decode($cadena);
	   $file = $nombreImagen.'.jpg';
	   $success = file_put_contents($file, $data);
	   return "cantidad:".$cant;
	   
	   */
		/*
		$cant = count($contenido);
	$x = 0;
	$y = 0;
	


 // Create new image with desired dimensions
  $image = imagecreatetruecolor($width, $heigth) or die("No se puede crear");
	for($i=0; $i<$cant; $i++){
		$binary=base64_decode($contenido[$i]);
		$imag = imagecreatefromstring($binary);
		$w = ImageSX($imag); // width
		$h = ImageSY($imag); // height
		$arrImag[$i] = $imag;
		//imagejpeg($imag, "prueba".$i."jpg");
	}
		$i = 0;
		for ($j=0; $j<4; $j++){
			for($k=0; $k<4; $k++){
				imagecopy($image, $arrImag[$i], $k*$w, $j*$h, 0, 0, $w, $h);
				$i++;
			}
		}

  
	 imagejpeg($image, $nombreImagen."jpg");
 // Clean up
	unset($arrImag);
 imagedestroy($image);
 imagedestroy($imag);
 return "cantidad:".$cant	;
*/
	}

   function recibeImagen($nombreImagen, $latitud, $longitud, $comentario,$idCategoria, $calificacion) {
  		
   		$link = mysql_connect("localhost", "root","root"); 
      	mysql_select_db("turismo", $link); 
      	mysql_query("SET NAMES 'utf8'");
      	$result = mysql_query("insert into imagen values('".$nombreImagen."',".$latitud.",".$longitud.",'".$comentario."',".$idCategoria.",".$calificacion.");", $link);
      	 
   		return "Insertado";
	
   }

   function obtieneCategorias() {
   	
	   	
   	
		$link = mysql_connect("localhost", "root","root"); 
      mysql_select_db("turismo", $link); 
      $result = mysql_query("select idCategoria, nombreCategoria from categoria", $link); 
    
	  $cont = 0;
	  while ($row = mysql_fetch_row($result)){ 
         $cat[$cont] = array("idCategoria" =>utf8_encode($row[0]),"nombreCategoria" => utf8_encode($row[1]));
		   $cont++;
      }
	 $listaCategorias = array("categoria"=>$cat);
     return $listaCategorias;   	
   }
   
   function enviaCorreo($correoContacto, $nombreImagen, $contenido){
   	include("libmail/class.phpmailer.php");
      include("libmail/class.smtp.php");
      
      
      $mail = new PHPMailer();
      $mail->IsSMTP();
      $mail->SMTPAuth = true;
      $mail->SMTPSecure = "ssl";
      $mail->Host = "smtp.gmail.com";
      $mail->Port = 465;
      $mail->Username = "sisfotosturisticas@gmail.com";
      $mail->Password = "adminsisfotos";
	  
      $mail->From = "sisfotosturisticas@gmail.com";
      $mail->FromName = "Notificaciones de sitios turísticos";
      $mail->Subject = $titulo;
      $mail->AltBody = "Correo";
      $mail->MsgHTML($contenido);
//      $mail->AddAttachment("files/files.zip");
 //     $mail->AddAttachment("files/img03.jpg");
      $mail->AddAddress($destinatario, "Destinatario");
      $mail->IsHTML(true);
      if(!$mail->Send()) {
        return $mail->ErrorInfo;
      } else {
        return "Mensaje enviado correctamente";
      }
   }
   
   
   
   function tep_validate_password($plain, $encrypted) {
    if (tep_not_null($plain) && tep_not_null($encrypted)) {
// split apart the hash / salt
      $stack = explode(':', $encrypted);

      if (sizeof($stack) != 2) return false;

      if (md5($stack[1] . $plain) == $stack[0]) {
        return true;
      }
    }

    return false;
  }

////
// This function makes a new password from a plaintext password. 
  function tep_encrypt_password($plain) {
    $password = '';

    for ($i=0; $i<10; $i++) {
      $password .= tep_rand();
    }

    $salt = substr(md5($password), 0, 2);

    $password = md5($salt . $plain) . ':' . $salt;

    return $password;
  }
  
  function tep_rand($min = null, $max = null) {
      static $seeded;
  
      if (!isset($seeded)) {
        mt_srand((double)microtime()*1000000);
        $seeded = true;
      }
  
      if (isset($min) && isset($max)) {
        if ($min >= $max) {
          return $min;
        } else {
          return mt_rand($min, $max);
        }
      } else {
        return mt_rand();
      }
    }
	
	function tep_not_null($value) {
    if (is_array($value)) {
      if (sizeof($value) > 0) {
        return true;
      } else {
        return false;
      }
    } else {
      if ( (is_string($value) || is_int($value)) && ($value != '') && ($value != 'NULL') && (strlen(trim($value)) > 0)) {
        return true;
      } else {
        return false;
      }
    }
  }
   
   
   ini_set("soap.wsdl_cache_enabled","0");
   $server = new SoapServer("http://localhost/pags/servicios/servicios.wsdl");
   $server->addFunction("obtieneListaContacto");
   $server->addFunction("validaUsuario");
   $server->addFunction("nuevoContacto");
   $server->addFunction("nuevoUsuario");
   $server->addFunction("enviaImagen");
   $server->addFunction("recibeImagen");
   $server->addFunction("obtieneCategorias");
   $server->addFunction("recibeImaArreglo");
   $server->addFunction("obtieneImagenes");   
   
   $server -> handle();
 
?>