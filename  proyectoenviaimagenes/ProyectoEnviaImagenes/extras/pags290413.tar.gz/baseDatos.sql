create database turismo;
use turismo;
create table categoria(idCategoria int not null, nombreCategoria varchar(40) not null, constraint idCategoriaPK primary key(idCategoria) );
create table estados(idEstado int not null, nombreEstado varchar(40) not null, constraint idEstadoPK primary key(idEstado) );

insert into categoria values(1, 'Hotel'),
	(2, 'Restaurante'), 
	(3, 'Mercado'),
	(4, 'Sitio arqueológico'),
	(5, 'Museo'),
	(6, 'Diversión'),
	(7, 'Sitio turistico');
	(7, 'Otro');
	
