-- MySQL dump 10.13  Distrib 5.5.29, for debian-linux-gnu (i686)
--
-- Host: localhost    Database: turismo
-- ------------------------------------------------------
-- Server version	5.5.29-0ubuntu0.12.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categoria`
--

DROP TABLE IF EXISTS `categoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categoria` (
  `idCategoria` int(11) NOT NULL,
  `nombreCategoria` varchar(40) NOT NULL,
  PRIMARY KEY (`idCategoria`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoria`
--

LOCK TABLES `categoria` WRITE;
/*!40000 ALTER TABLE `categoria` DISABLE KEYS */;
INSERT INTO `categoria` VALUES (1,'Hotel'),(2,'Museo'),(3,'Mercado'),(4,'Sitio Turístico'),(5,'Artesanías'),(6,'Balneario'),(7,'Cascada'),(8,'Gruta'),(9,'Lago-Laguna'),(10,'Monumento Colonial'),(11,'Parque Nacional'),(12,'Playa'),(13,'Zona Arqueológica'),(14,'Otro');
/*!40000 ALTER TABLE `categoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estados`
--

DROP TABLE IF EXISTS `estados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estados` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clave` varchar(2) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `abrev` varchar(16) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COMMENT='Tabla de Estados de la República Mexicana';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estados`
--

LOCK TABLES `estados` WRITE;
/*!40000 ALTER TABLE `estados` DISABLE KEYS */;
INSERT INTO `estados` VALUES (1,'01','Aguascalientes','Ags.'),(2,'02','Baja California','BC'),(3,'03','Baja California Sur','BCS'),(4,'04','Campeche','Camp.'),(5,'05','Coahuila de Zaragoza','Coah.'),(6,'06','Colima','Col.'),(7,'07','Chiapas','Chis.'),(8,'08','Chihuahua','Chih.'),(9,'09','Distrito Federal','DF'),(10,'10','Durango','Dgo.'),(11,'11','Guanajuato','Gto.'),(12,'12','Guerrero','Gro.'),(13,'13','Hidalgo','Hgo.'),(14,'14','Jalisco','Jal.'),(15,'15','México','Mex.'),(16,'16','Michoacán de Ocampo','Mich.'),(17,'17','Morelos','Mor.'),(18,'18','Nayarit','Nay.'),(19,'19','Nuevo León','NL'),(20,'20','Oaxaca','Oax.'),(21,'21','Puebla','Pue.'),(22,'22','Querétaro','Qro.'),(23,'23','Quintana Roo','Q. Roo'),(24,'24','San Luis Potosí','SLP'),(25,'25','Sinaloa','Sin.'),(26,'26','Sonora','Son.'),(27,'27','Tabasco','Tab.'),(28,'28','Tamaulipas','Tamps.'),(29,'29','Tlaxcala','Tlax.'),(30,'30','Veracruz de Ignacio de la Llave','Ver.'),(31,'31','Yucatán','Yuc.'),(32,'32','Zacatecas','Zac.');
/*!40000 ALTER TABLE `estados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagen`
--

DROP TABLE IF EXISTS `imagen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imagen` (
  `nombreImagen` varchar(35) NOT NULL,
  `latitud` double NOT NULL,
  `longitud` double NOT NULL,
  `comentario` varchar(255) DEFAULT NULL,
  `idCategoria` int(11) NOT NULL,
  PRIMARY KEY (`nombreImagen`),
  KEY `idCategoriaFK` (`idCategoria`),
  CONSTRAINT `idCategoriaFK` FOREIGN KEY (`idCategoria`) REFERENCES `categoria` (`idCategoria`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagen`
--

LOCK TABLES `imagen` WRITE;
/*!40000 ALTER TABLE `imagen` DISABLE KEYS */;
INSERT INTO `imagen` VALUES ('FT1366381176580.jpg',17.04633581,-96.71160824,'biblioteca ',14),('FT1366381217086.jpg',17.04705983,-96.71115617,'cevie ',14),('FT1366399400752.jpg',17.04642435,-96.71204143,'hola cas ',7);
/*!40000 ALTER TABLE `imagen` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-04-19 15:13:29
