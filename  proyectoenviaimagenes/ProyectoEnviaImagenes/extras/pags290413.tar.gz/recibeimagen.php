<?php

/*
en php.ini
; Maximum allowed size for uploaded files.
; http://php.net/upload-max-filesize
upload_max_filesize = 10M

--

$ chmod +x file.cgi
*/
$target_path  = "./";
$target_path = $target_path.basename( $_FILES['uploadedfile']['name']);
if(move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $target_path)) {
 echo "El archivo ".  basename( $_FILES['uploadedfile']['name']).
 " ha sido cargado al servidor";
} else{
 echo "Error, intentar nuevamente :S!";
}
?>
