<?php
   function enviaImagen($nombreImagen, $contenido, $latitud, $longitud, $comentario, $categoria) {
   	
   	$binary=base64_decode($contenido);

		// binary, utf-8 bytes

		header('Content-Type: image/jpeg');
//activar la biblioteca de funciones gd
		$img = imagecreatefromstring($binary);
		
		if($img != false)
		{
   		imagejpeg($img,$nombreImagen.".jpg");
   		
   		$link = mysql_connect("localhost", "root","root"); 
      	mysql_select_db("turismo", $link); 
      	$result = mysql_query("insert into imagen values('".$nombreImagen."',".$latitud.",".$longitud.",'".$comentario."',".$categoria.");", $link);
      	 
   		return "recibido";
		}
		else {
		   return "error";	
		}			
		

   }
   
      function recibeImagen($imagen, $nombreIm) {
   	
   	$binary=base64_decode($imagen);

		// binary, utf-8 bytes

		header('Content-Type: image/jpeg');
//activar la biblioteca de funciones gd

		$img = imagecreatefromstring($binary);
		
		if($img != false)
		{
   		imagejpeg($img,$nombreIm);
   		return "recibido";
		}
		else {
		   return "error";	
		}			
		

   }
   
   function obtieneCategorias() {
   	
	   	
   	
		$link = mysql_connect("localhost", "root","root"); 
      mysql_select_db("turismo", $link); 
      $result = mysql_query("select idCategoria, nombreCategoria from categoria", $link); 
    
	  $cont = 0;
	  while ($row = mysql_fetch_row($result)){ 
         $cat[$cont] = array("idCategoria" =>utf8_encode($row[0]),"nombreCategoria" => utf8_encode($row[1]));
		   $cont++;
      }
	 $listaCategorias = array("categoria"=>$cat);
     return $listaCategorias;   	
   }
   
   
   function pegaImagenes($imagenes, $width_x, $height_y){
//http://diceattack.wordpress.com/2011/01/03/combining-multiple-images-using-php-and-gd/
//http://www.cemetech.net/forum/viewtopic.php?t=6518&start=0
//http://stackoverflow.com/questions/8858489/merge-two-images-in-php
      // Create new image with desired dimensions


         
        	
   }
   
   ini_set("soap.wsdl_cache_enabled","0");
   $server = new SoapServer("http://localhost/pags/servicios/servicios.wsdl");
   
   $server->addFunction("enviaImagen");
   $server->addFunction("recibeImagen");
   $server->addFunction("obtieneCategorias");
   
   $server -> handle();
 
?>